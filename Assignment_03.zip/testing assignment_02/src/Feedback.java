import java.util.ArrayList;
import java.util.List;

public class Feedback {

    private String doctorId;         // ID of the providing doctor
    private String patientId;       // ID of the receiving patient
    private String notes;           // Doctor's comments
    private List<Prescription> prescriptions;  // Associated medications

    // Creates new feedback with empty prescription list
    public Feedback(String doctorId, String patientId, String notes) {
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.notes = notes;
        this.prescriptions = new ArrayList<>();
    }

    //Adds a prescription to this feedback entry
    public void add_Prescription(Prescription prescription) {
        prescriptions.add(prescription);
    }


    //Displays complete feedback
    public void display_Feedback() {
        System.out.println("\n=== Feedback ===");
        System.out.println("Doctor: " + doctorId);
        System.out.println("Patient: " + patientId);
        System.out.println("Notes: " + notes);

        if (!prescriptions.isEmpty()) {
            System.out.println("\nPrescriptions:");
            for (Prescription p : prescriptions) {
                p.display_Prescription();
            }
        }
    }

    public List<Prescription> getPrescriptions() {
        return prescriptions;
    }
}