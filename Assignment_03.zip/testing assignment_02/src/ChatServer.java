import java.util.ArrayList;
import java.util.List;

public class ChatServer {
    private List<String> messageHistory = new ArrayList<>();

    public void receiveMessage(String message) {
        messageHistory.add(message);
        System.out.println(message);
    }

    public void displayHistory() {
        System.out.println("\n=== Chat History ===");
        for (String message : messageHistory) {
            System.out.println(message);
        }
    }

    public void clearHistory() {
        messageHistory.clear();
    }
}