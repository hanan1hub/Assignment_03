import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Patient extends User {
    // Patient-specific medical attributes
    private String gender;
    private String bloodGroup;
    // Tracks all vital sign measurements for the patient
    private List<Vital_Sign> vitals;
    // Complete medical record including prescriptions and feedback
    private Medical_History medicalHistory;

    private String email;
    private String emergencyContact;
    public Patient(String id, String name, String gender, String bloodGroup,String email, String emergencyContact) {
        super(id, name, "Patient");
        this.gender = gender;
        this.bloodGroup = bloodGroup;
        this.vitals = new ArrayList<>();
        this.medicalHistory = new Medical_History();
        this.email = email;
        this.emergencyContact = emergencyContact;
    }


     //Interactive method to create new patient by input
     public static Patient create_Patient(Scanner scanner) {
         System.out.println("\n\t--- Create New Patient ---");
         System.out.print("Enter ID: ");
         String id = scanner.nextLine();
         System.out.print("Enter Name: ");
         String name = scanner.nextLine();
         System.out.print("Enter Gender: ");
         String gender = scanner.nextLine();
         System.out.print("Enter Blood Group: ");
         String bloodGroup = scanner.nextLine();
         System.out.print("Enter Email: ");
         String email = scanner.nextLine();
         System.out.print("Enter Emergency Contact: ");
         String emergencyContact = scanner.nextLine();

         return new Patient(id, name, gender, bloodGroup, email, emergencyContact);
     }

    // getters
    public String getGender() {
        return gender;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public List<Vital_Sign> getVitals() {
        return this.vitals;
    }

    public Medical_History get_Medical_History() {
        return this.medicalHistory;
    }

    public String getEmail() {
        return email;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }
    //Captures and stores new vital sign measurements by input
    public void upload_Vitals(Scanner scanner) {
        System.out.println("\n\t--- Upload Vitals ---");
        System.out.print("Heart Rate: ");
        int heartRate = scanner.nextInt();
        System.out.print("Oxygen Level: ");
        double oxygenLevel = scanner.nextDouble();
        scanner.nextLine(); // consume newline
        System.out.print("Blood Pressure (e.g.120/80): ");
        String bloodPressure = scanner.nextLine();

        Vital_Sign vital = new Vital_Sign(this.id, heartRate, oxygenLevel, bloodPressure);
        this.vitals.add(vital);
        System.out.println("Vitals uploaded successfully!");
    }

    //Displays patient information including medical attributes
    @Override
    public void display_Info() {
        System.out.println("\tPatient Information:");
        System.out.println("ID: " + this.id);
        System.out.println("Name: " + this.name);
        System.out.println("Gender: " + this.gender);
        System.out.println("Blood Group: " + this.bloodGroup);
        System.out.println("E-Mail: "+this.email);
        System.out.println("Emergency Contact Number: "+this.emergencyContact);
    }
}