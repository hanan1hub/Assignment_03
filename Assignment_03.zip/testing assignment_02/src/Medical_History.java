import java.util.ArrayList;
import java.util.List;

public class Medical_History {
    // Stores all feedback
    private List<Feedback> feedbackList;

    public Medical_History() {
        this.feedbackList = new ArrayList<>();
    }

    //Adds new medical feedback to the patient's history
    public void add_Feedback(Feedback feedback) {
        feedbackList.add(feedback);
    }

    //Displays the complete medical history
    public void display_Feedback() {
        if (feedbackList.isEmpty()) {
            System.out.println("\nNo medical history recorded yet.");
            return;
        }
        System.out.println("\n=== MEDICAL HISTORY ===");
        for (int i = 0; i < feedbackList.size(); i++) {
            System.out.println("\nEntry #" + (i+1));
            feedbackList.get(i).display_Feedback();
        }
    }
}