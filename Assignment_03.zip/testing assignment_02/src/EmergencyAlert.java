public class EmergencyAlert {
    // Reference to NotificationService to send alerts (via email, SMS, etc.)
    private NotificationService notificationService;

    public EmergencyAlert(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    public void checkVitals(Vital_Sign vital, Patient patient) {
        boolean critical = false;
        String message = "";

        // Check for abnormal heart rate (too high or too low)
        if (vital.getheartRate() > 120 || vital.getheartRate() < 50) {
            message += "Abnormal heart rate detected!\n";
            critical = true;
        }

        // Check for low oxygen level
        if (vital.getoxygenLevel() < 90) {
            message += "Low oxygen level detected!\n";
            critical = true;
        }

        // If any vital sign is critical, notify the doctor assigned to the patient
        if (critical) {
            message += "Immediate attention required for patient: " + patient.getName();
            notificationService.sendEmergencyAlert(patient.getEmail(),patient.getEmergencyContact(), message);
        }
    }
}