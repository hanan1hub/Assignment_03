public class Prescription {
    private String medicine;    // Name of prescribed medication
    private String dosage;     // Amount per dose
    private String schedule;   // Frequency

    // Creates a new prescription
    public Prescription(String medicine, String dosage, String schedule) {
        this.medicine = medicine;
        this.dosage = dosage;
        this.schedule = schedule;
    }

    // Displays prescription details
    public void display_Prescription() {
        System.out.println("\nMedicine: " + medicine);
        System.out.println("Dosage: " + dosage);
        System.out.println("Schedule: " + schedule);
    }
}