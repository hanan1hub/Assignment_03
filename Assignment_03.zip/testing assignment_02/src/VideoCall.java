import java.awt.Desktop;
import java.net.URI;


class VideoCall {
    public String meetingLink;

    public VideoCall(String meetingLink) {
        this.meetingLink = meetingLink;
    }

    public  void joinCall(String participantName) {
        System.out.println("\n " + participantName + " is joining the video call...");
        System.out.println("Opening the meeting link: " + meetingLink);

        try {
            // Get the desktop instance of the system
            Desktop desktop = Desktop.getDesktop();
            // Check if browsing is supported, then open the meeting link
            if (desktop.isSupported(Desktop.Action.BROWSE)) {
                desktop.browse(new URI(meetingLink));
            } else {
                System.err.println("Browser opening not supported on this system.");
            }
        } catch (Exception e) {
            // Handle errors such as invalid URI or unsupported platform
            System.err.println("Failed to open browser: " + e.getMessage());
        }
    }
}