public class SMSNotification implements Notifiable {
    @Override
    public void sendNotification(String phoneNumber, String message) {
        if (!isValidPhoneNumber(phoneNumber)) {
            System.out.println("❌ Invalid phone number: " + phoneNumber);
            return;
        }

        System.out.println("\n[SMS ALERT] Sending to: " + formatPhoneNumber(phoneNumber));
        System.out.println("Message: " + message);
        System.out.println("--------------------------");

        // Actual SMS sending logic would go here
    }

    private boolean isValidPhoneNumber(String phone) {
        return phone != null && phone.matches("^\\+?[0-9]{10,15}$");
    }

    private String formatPhoneNumber(String phone) {
        return phone.replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
    }
}