import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Vital_Sign {
    // Patient identifier for whom vitals are recorded
    private String patientId;
    // Automatic timestamp when vitals are taken
    private LocalDateTime timestamp;
    // Heart rate in beats per minute
    private int heartRate;
    // Blood oxygen saturation percentage
    private double oxygenLevel;
    // Blood pressure reading (e.g."120/80")
    private String bloodPressure;

    public Vital_Sign(String patientId, int heartRate, double oxygenLevel, String bloodPressure) {
        this.patientId = patientId;
        this.timestamp = LocalDateTime.now(); // Auto-record creation time
        this.heartRate = heartRate;
        this.oxygenLevel = oxygenLevel;
        this.bloodPressure = bloodPressure;
    }

    // Displays  vital sign information
    public void display_Vitals() {
        System.out.println("\nVital Signs for Patient: " + patientId);
        System.out.println("Time: " + timestamp.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        System.out.println("Heart Rate: " + heartRate);
        System.out.println("Oxygen Level: " + oxygenLevel);
        System.out.println("Blood Pressure: " + bloodPressure);
    }

    // Getter methods
    public String getPatientId() {
        return patientId;
    }

    public int getheartRate() {
        return heartRate;
    }

    public double getoxygenLevel() {
        return oxygenLevel;
    }

    public String getBloodPressure() {
        return bloodPressure;
    }
}