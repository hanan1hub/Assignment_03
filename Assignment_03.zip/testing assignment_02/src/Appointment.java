public class Appointment {
    //  appointment attributes
    private String appointmentId;      // Unique identifier for the appointment
    private String patientId;          // ID of the patient
    private String doctorId;           // ID of the attending doctor
    private String date;               // Scheduled date/time of appointment
    private String status;             // Tracks appointment status (Pending/Completed/Cancelled)

    public Appointment(String appointmentId, String patientId, String doctorId, String date) {
        this.appointmentId = appointmentId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
        this.status = "Pending"; // Initial status
    }

    // Displays appointment details
    public void display_Appointment() {
        System.out.println("\nAppointment ID: " + appointmentId);
        System.out.println("Patient ID: " + patientId);
        System.out.println("Doctor ID: " + doctorId);
        System.out.println("Date: " + date);
        System.out.println("Status: " + status);
    }

   //Updates the appointment's status
    public void set_Status(String status) {
        this.status = status;
    }
}