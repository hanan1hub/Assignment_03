public class PanicButton {
    private EmergencyAlert emergencyAlert;
    private NotificationService notificationService;

    public PanicButton(EmergencyAlert emergencyAlert, NotificationService notificationService) {
        this.emergencyAlert = emergencyAlert;
        this.notificationService = notificationService;
    }

    public void press(Vital_Sign currentVitals, Patient patient) {
        System.out.println("⚠ Panic button pressed by " + patient.getName());

        System.out.println("Sending Message....Wait a Moment..");
        // Prepare emergency message
        String message = String.format(
                "EMERGENCY ALERT for %s (ID: %s)\n" +
                        "Critical Vitals:\n" +
                        "- Heart Rate: %d bpm\n" +
                        "- Oxygen Level: %.1f%%\n" +
                        "- Blood Pressure: %s\n" +
                        "Immediate attention required!",
                patient.getName(),
                patient.getId(),
                currentVitals.getheartRate(),
                currentVitals.getoxygenLevel(),
                currentVitals.getBloodPressure()
        );

        // Send alerts through notification service
        notificationService.sendEmergencyAlert(
                patient.getEmail(),
                patient.getEmergencyContact(),
                message
        );

        // Also check vitals through emergency alert
        emergencyAlert.checkVitals(currentVitals, patient);
    }
}