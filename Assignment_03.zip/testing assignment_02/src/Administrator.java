import java.util.ArrayList;
import java.util.List;

public class Administrator extends User {
    // Lists to track all doctors and patients in the system
    private List<Doctor> doctors;
    private List<Patient> patients;

    public Administrator(String id, String name, String designation) {
        super(id, name, designation);
        this.doctors = new ArrayList<>();
        this.patients = new ArrayList<>();
    }

    // Adds a doctor to the system
    public void addDoctor(Doctor doctor) {
        doctors.add(doctor);
    }

    // Adds a patient to the system
    public void addPatient(Patient patient) {
        patients.add(patient);
    }

    // Returns the list of all doctors
    public List<Doctor> getDoctors() {
        return this.doctors;
    }

    // Returns the list of all patients
    public List<Patient> getPatients() {
        return this.patients;
    }

    //Displays all users (doctors and patients) in the system
    public void display_All_Users() {
        System.out.println("\n--- All Users ---");
        System.out.println("Doctors:");
        for (Doctor d : doctors) {
            d.display_Info();
        }
        System.out.println("\nPatients:");
        for (Patient p : patients) {
            p.display_Info();
        }
    }
}