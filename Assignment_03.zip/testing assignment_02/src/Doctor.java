import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Doctor extends User {
    // Tracks all patients assigned to this doctor
    private List<Patient> patients;

      //Creates a new doctor with an empty patient list
    public Doctor(String id, String name, String designation) {
        super(id, name, designation);
        this.patients = new ArrayList<>();
    }

    // method to create new doctor by input
    public static Doctor create_Doctor(Scanner scanner) {
        System.out.println("\n\t--- Create New Doctor ---");
        System.out.print("Enter ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter Designation: ");
        String designation = scanner.nextLine();

        return new Doctor(id, name, designation);
    }

    public void add_Patient(Patient patient) {
        this.patients.add(patient);
    }

    // method to provide medical feedback and prescriptions
    public void provide_Feedback(Scanner scanner, Patient patient) {
        System.out.println("\n\t--- Provide Feedback ---");
        System.out.println("For patient: " + patient.getName());
        System.out.print("Enter Feedback Note: ");
        String notes = scanner.nextLine();

        Feedback feedback = new Feedback(this.id, patient.getId(), notes);

        // Prescription entry loop
        System.out.print("\nAdd prescription? (y/n): ");
        String choice = scanner.nextLine();

        while (choice.equalsIgnoreCase("y")) {
            System.out.println("\n--- New Prescription ---");
            System.out.print("Medicine Name: ");
            String medicine = scanner.nextLine();

            System.out.print("Dosage (e.g. 500mg): ");
            String dosage = scanner.nextLine();

            System.out.print("Schedule (e.g. 3 times daily): ");
            String schedule = scanner.nextLine();

            feedback.add_Prescription(new Prescription(medicine, dosage, schedule));

            System.out.print("\nAdd another prescription? (y/n): ");
            choice = scanner.nextLine();
        }

        patient.get_Medical_History().add_Feedback(feedback);
        System.out.println("\n Feedback and prescriptions added successfully!");
    }

    //Displays all vital signs for a specific patient
    public void view_Patient_Vitals(Patient patient) {
        System.out.println("\n\t--- Patient Vitals ---");
        for (Vital_Sign vital : patient.getVitals()) {
            vital.display_Vitals();
        }
    }
}